import numpy
import math
import matplotlib.pyplot as plt


# 生成随机[0， 1]数据
# num 数据大小
def get_random_data(num):
    x = numpy.linspace(0, 1, num)
    y = numpy.sin(2 * math.pi * x)
    for t in range(len(x)):
        y[t] = y[t] + numpy.random.normal(0, 0.2, 1)

    return [x, y]


# 根据数据节点生成X矩阵
# size M值
def create_input_matrix(input_tensor, size):
    result = []
    for t in range(len(input_tensor)):
        result.append([])
        for p in range(size):
            result[t].append(input_tensor[t] ** p)

    return numpy.mat(result)


# 计算系数W 与loss值
def calculate_weight(size):
    # 训练集
    training_data = get_random_data(TRAINING_DATA_NUM)
    X = numpy.mat(create_input_matrix(training_data[0], size))
    t = numpy.mat(training_data[1])
    # 解析法计算w
    w = (X.T * X).I * X.T * t.T

    # 验证集
    validation_data = get_random_data(30)
    X = numpy.mat(create_input_matrix(validation_data[0], size))
    t = numpy.mat(validation_data[1])

    # 计算loss
    tmp = X * w - t.T
    loss = math.sqrt(tmp.T * tmp / len(X))

    # 输出训练集与验证集
    plt.scatter(training_data[0], training_data[1], label="training data")
    plt.scatter(validation_data[0], validation_data[1], label="validation data")

    return [w, loss]


# 图形化显示实验结果
def show_result():
    for index in range(10):
        plt.subplot(2, 5, index + 1)
        weight = calculate_weight(index + 1)
        data1 = numpy.linspace(0, 1, 100)
        y = (create_input_matrix(data1, index + 1) * weight[0]).T
        plt.plot(data1, numpy.sin(2 * math.pi * data1))
        plt.plot(data1, y.tolist()[0], label="y = f(w, x), m = " + str(index))
        plt.plot(data1, numpy.sin(2 * math.pi * data1), label="y = sin(2πx)")

        plt.title("loss = " + str(weight[1]) + "\ntraining data = " + str(TRAINING_DATA_NUM))

        test_data = get_random_data(10)
        plt.scatter(test_data[0], test_data[1], label="test data")

        plt.legend(loc='upper right')

    plt.show()


# 训练集大小
TRAINING_DATA_NUM = 10

show_result()
