import numpy
import math
import matplotlib.pyplot as plt


# 生成随机[0， 1]数据
# num 数据大小
def get_random_data(num):
    x = numpy.linspace(0, 1, num)
    y = numpy.sin(2 * math.pi * x)
    for t in range(len(x)):
        y[t] = y[t] + numpy.random.normal(0, 0.2, 1)

    return [x, y]


# 根据数据节点生成X矩阵
# size M值
def create_input_matrix(input_tensor, size):
    result = []
    for t in range(len(input_tensor)):
        result.append([])
        for p in range(size):
            result[t].append(input_tensor[t] ** p)

    return numpy.mat(result)


# 计算权值向量w与loss值
# traning_data 训练数据
# size m值
# division 惩罚因子
def calculate_weight_with_penalty(size, divisor):
    # 训练集
    training_data = get_random_data(10)
    X = numpy.mat(create_input_matrix(training_data[0], size))
    t = numpy.mat(training_data[1])
    # 单位矩阵
    unit_matrix = numpy.eye(len(X.T), len(X.T))
    # 计算 W 向量
    w = (X.T * X + (divisor * unit_matrix)).I * X.T * t.T

    #验证集
    validation_data = get_random_data(30)
    X = numpy.mat(create_input_matrix(validation_data[0], size))
    t = numpy.mat(validation_data[1])

    # 计算loss
    tmp = X * w - t.T
    loss = math.sqrt(tmp.T * tmp / len(X))

    # 输出训练集与验证集
    plt.scatter(validation_data[0], validation_data[1], label="validation data")
    plt.scatter(training_data[0], training_data[1], label="training data")

    return [w, loss]


# 图形化显示实验结果
def show_result(m, divisor):
    # 计算系数W 与loss值
    weight = calculate_weight_with_penalty(m, divisor)

    data1 = numpy.linspace(0, 1, 100)
    y = (create_input_matrix(data1, m) * weight[0]).T
    plt.plot(data1, numpy.sin(2 * math.pi * data1), label="y = sin(2πx)")
    plt.plot(data1, y.tolist()[0], label="y = f(w, x)")
    plt.title("loss = " + str(weight[1]) + "\nλ = " + str(divisor))

    test_data = get_random_data(10)
    plt.scatter(test_data[0], test_data[1], label="test data")
    plt.legend()

    plt.show()


# M值
M = 10
# 惩罚因子
DIVISIOR = 0.000001

show_result(M, DIVISIOR)
