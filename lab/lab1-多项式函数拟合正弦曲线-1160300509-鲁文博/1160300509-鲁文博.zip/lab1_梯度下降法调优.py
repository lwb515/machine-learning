import numpy
import math
import matplotlib.pyplot as plt


# 生成随机[0， 1]数据
# num 数据大小
def get_random_data(num):
    x = numpy.linspace(0, 1, num)
    y = numpy.sin(2 * math.pi * x)
    for t in range(len(x)):
        y[t] = y[t] + numpy.random.normal(0, 0.2, 1)

    return [x, y]


# 根据数据节点生成X矩阵
# size M值
def create_input_matrix(input_tensor, size):
    result = []
    for t in range(len(input_tensor)):
        result.append([])
        for p in range(size + 1):
            result[t].append(input_tensor[t] ** p)

    return numpy.mat(result)


# 梯度下降法优化
# size M， max_times 迭代次数， learning_rate学习率,  divisor 惩罚因子
# def grad_descent_optimize(size, threshold, learning_rate):
def grad_descent_optimize_with_penatly(size, max_times, learning_rate, divisor):
    # 训练集
    training_data = get_random_data(10)
    X = numpy.mat(create_input_matrix(training_data[0], size))
    Y = numpy.mat(training_data[1])

    # 初始化W = [0, 0..., 0]
    W = numpy.mat(numpy.zeros(size + 1))
    # 计算梯度
    grad = X.T * ((X * W.T) - Y.T) + (divisor * W.T)
    iter_times = 0
    while iter_times < max_times:
        W = W - (learning_rate * grad).T
        # 更新梯度
        grad = X.T * ((X * W.T) - Y.T) + (divisor * W.T)
        iter_times = iter_times + 1

    # 验证集
    validation_data = get_random_data(30)
    X = numpy.mat(create_input_matrix(validation_data[0], size))
    Y = numpy.mat(validation_data[1])

    # 计算loss
    tmp = X * W.T - Y.T
    loss = math.sqrt(tmp.T * tmp / len(X))

    # 输出训练集与验证集
    plt.scatter(validation_data[0], validation_data[1], label="validation data")
    plt.scatter(training_data[0], training_data[1], label="training data")

    return [W.T, loss]


# 图形化显示实验结果
def show_result(m, max_times, learning_rate, divisor):
    # 计算系数W 与loss值
    weight = grad_descent_optimize_with_penatly(m, max_times, learning_rate, divisor)

    data1 = numpy.linspace(0, 1, 100)
    y = (create_input_matrix(data1, m) * weight[0]).T
    plt.plot(data1, numpy.sin(2 * math.pi * data1), label="y = sin(2πx)")
    plt.plot(data1, y.tolist()[0], label="y = f(w, x)")
    title = "loss = " + str(weight[1]) + "\n" + "LR = " + str(LR) \
            + ",  M = " + str(m) + ",  ITER_TIMES = " + str(max_times) + ",  λ = " + str(divisor)
    plt.title(title)

    test_data = get_random_data(10)
    plt.scatter(test_data[0], test_data[1], label="test data")
    plt.legend()

    plt.show()


# M值
M = 10
# 迭代次数
ITER_TIMES = 200000
# 学习率
LR = 0.001
# 惩罚因子 无惩罚项可设置为0
DIVISOR = 0.0001

show_result(M, ITER_TIMES, LR, DIVISOR)
