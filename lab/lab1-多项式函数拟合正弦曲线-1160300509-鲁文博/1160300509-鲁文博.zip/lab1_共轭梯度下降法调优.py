import numpy
import math
import matplotlib.pyplot as plt


# 生成随机[0， 1]数据
# num 数据大小
def get_random_data(num):
    x = numpy.linspace(0, 1, num)
    y = numpy.sin(2 * math.pi * x)
    for t in range(len(x)):
        y[t] = y[t] + numpy.random.normal(0, 0.2, 1)

    return [x, y]


# 根据数据节点生成X矩阵
# size M值
def create_input_matrix(input_tensor, size):
    result = []
    for t in range(len(input_tensor)):
        result.append([])
        for p in range(size + 1):
            result[t].append(input_tensor[t] ** p)

    return numpy.mat(result)


# 共轭梯度下降法优化
# size M   divisor 惩罚因子
def conjugate_grad_descent_optimize_with_penatly(size, divisor):
    # 训练集
    training_data = get_random_data(10)
    X = numpy.mat(create_input_matrix(training_data[0], size))
    Y = numpy.mat(training_data[1])

    # 初始化W = [0, 0..., 0]
    W = numpy.mat(numpy.zeros(size + 1)).T

    # 共轭梯度求解
    r = (X.T * Y.T) - (X.T * X * W) - (divisor * W)
    p = r
    for t in range(30):
        a = (r.T * r) / (p.T * (X.T * X + divisor * numpy.eye(len(W))) * p)
        W = W + (float(a) * p)
        tmp = r.T * r
        r = r - (float(a) * (X.T * X + divisor * numpy.eye(len(W))) * p)
        b = (r.T * r) * tmp.I
        p = r + (float(b) * p)

    # 验证集
    validation_data = get_random_data(30)
    X = numpy.mat(create_input_matrix(validation_data[0], size))
    Y = numpy.mat(validation_data[1])

    # 计算loss
    tmp = X * W - Y.T
    loss = math.sqrt(tmp.T * tmp / len(X))

    # 输出训练集与验证集
    plt.scatter(validation_data[0], validation_data[1], label="validation data")
    plt.scatter(training_data[0], training_data[1], label="training data")
    return [W, loss]


# 图形化显示实验结果
def show_result(m, divisor):
    # 计算系数W 与loss值
    weight = conjugate_grad_descent_optimize_with_penatly(m, divisor)

    data1 = numpy.linspace(0, 1, 100)
    y = (create_input_matrix(data1, m) * weight[0]).T
    plt.plot(data1, numpy.sin(2 * math.pi * data1), label="y = sin(2πx)")
    plt.plot(data1, y.tolist()[0], label="y = f(w, x)")
    title = "loss = " + str(weight[1]) + "\n" + "M = " + str(M) + ",  λ = " + str(divisor)
    plt.title(title)

    test_data = get_random_data(10)
    plt.scatter(test_data[0], test_data[1])
    plt.legend()

    plt.show()


# M值
M = 10
# 惩罚因子 无惩罚项可设置为0
DIVISOR = 0.0009

show_result(M, DIVISOR)
